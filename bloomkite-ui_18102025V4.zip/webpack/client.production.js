const { merge } = require('webpack-merge');
const common = require('./common');
const { join } = require('path');
const path = require('path');
const ExtractCssChunksPlugin = require('extract-css-chunks-webpack-plugin');
const webpack = require('webpack');
// Removed @loadable/webpack-plugin - using direct imports
// Removed brotli-gzip-webpack-plugin - incompatible with webpack 5

module.exports = merge(common, {
    mode: 'production',
    name: 'client',
    target: 'web',
    entry: [join(__dirname, '../src/client/index')],
    devtool: 'hidden-source-map',
    output: {
        filename: '[name].[contenthash].js',
        chunkFilename: '[name].chunk.[contenthash].js'
    },
    module: {
        rules: [
            {
                test: /\.css$/,
                // exclude: /node_modules/,
                use: [
                    'isomorphic-style-loader',
                    ExtractCssChunksPlugin.loader,
                    {
                        loader: 'css-loader',
                        options: {
                            modules: {
                                localIdentName: '[local]'
                            },
                            url: false
                        }
                    },
                    {
                        loader: 'postcss-loader',
                        options: {}
                    }
                ]
            }
        ]
    },
    optimization: {
        // Removed runtimeChunk to avoid filename conflicts
        splitChunks: {
            chunks: 'initial',
            cacheGroups: {
                // vendors: {
                //     test: /[\\/]node_modules[\\/]/,
                //     name: 'vendor'
                // }
            }
        }
    },
    plugins: [
        // Removed LoadablePlugin - using direct imports
        new ExtractCssChunksPlugin(),
        // Custom plugin to generate stats.json for server-side rendering
        {
            apply: (compiler) => {
                compiler.hooks.emit.tapAsync('StatsPlugin', (compilation, callback) => {
                    const stats = compilation.getStats().toJson({
                        all: false,
                        assets: true,
                        chunks: true,
                        chunkModules: true,
                        modules: false,
                        publicPath: true
                    });
                    
                    const statsJson = JSON.stringify(stats, null, 2);
                    compilation.assets['stats.json'] = {
                        source: () => statsJson,
                        size: () => statsJson.length
                    };
                    callback();
                });
            }
        }
        // Removed BrotliGzipPlugin - incompatible with webpack 5
    ]
});
