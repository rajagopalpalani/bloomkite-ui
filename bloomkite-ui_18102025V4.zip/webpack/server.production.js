const { merge } = require('webpack-merge');
const webpack = require('webpack');
const common = require('./common');
const join = require('path').join;
const path = require('path');
const nodeExternals = require('../scripts/node-externals');
// Removed @loadable/webpack-plugin - using direct imports

module.exports = merge(common, {
    mode: 'production',
    name: 'server',
    target: 'node',
    externals: nodeExternals,
    entry: [join(__dirname, '../src/server/index')],
    devtool: 'hidden-source-map',
    output: {
        filename: 'app.server.js',
        libraryTarget: 'commonjs2'
    },
    resolve: {
        ...common.resolve
    },
    module: {
        rules: [
            {
                test: /\.css$/,
                use: [
                    'isomorphic-style-loader',
                    {
                        loader: 'css-loader',
                        options: {
                            modules: {
                                localIdentName: '[local]'
                            },
                            url: false
                        }
                    },
                    {
                        loader: 'postcss-loader',
                        options: {}
                    },
                ]
            }
        ]
    },
    plugins: [
        // Removed LoadablePlugin - using direct imports
        new webpack.optimize.LimitChunkCountPlugin({
            maxChunks: 1
        })
    ]
});
