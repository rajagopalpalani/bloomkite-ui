const webpack = require('webpack');
const { merge } = require('webpack-merge');
const common = require('./common');
const { join } = require('path');
const path = require('path');
const ExtractCssChunksPlugin = require('extract-css-chunks-webpack-plugin');
// Removed @loadable/webpack-plugin - using direct imports

module.exports = merge(common, {
    mode: 'development',
    name: 'client',
    target: 'web',
    entry: {
        'app.client': [
            'webpack-hot-middleware/client',
            join(__dirname, '../src/client/index')
        ]
    },
    devtool: 'eval-cheap-module-source-map',
    output: {
        filename: '[name].js',
        chunkFilename: '[name].chunk.[contenthash].js',
        path: join(__dirname, '../public'),
        publicPath: '/'
    },
    // Removed node configuration - webpack 5 handles this automatically
    module: {
        rules: [
                {
                    test: /\.css$/,
                    exclude: /node_modules/,
                    use: [
                        "isomorphic-style-loader",
                        ExtractCssChunksPlugin.loader,
                        {
                            loader: 'css-loader',
                            options: {
                                modules: {
                                    localIdentName: '[local]'
                                },
                                url: false
                            }
                        },
                        {
                            loader: 'postcss-loader',
                            options: {
                                postcssOptions: {
                                    plugins: [
                                        require('postcss-import')()
                                    ]
                                }
                            }
                        }
                    ]
                },
            {
                test: /\.css$/,
                include: /node_modules/,
                use: [
                    "isomorphic-style-loader",
                    ExtractCssChunksPlugin.loader,
                    {
                        loader: 'css-loader',
                        options: {
                            url: false
                        }
                    },
                    {
                        loader: 'postcss-loader',
                        options: {
                            postcssOptions: {
                                plugins: [
                                    require('postcss-import')()
                                ]
                            }
                        }
                    }
                ]
            }
        ]
    },
    optimization: {
        runtimeChunk: {
            name: 'runtime'
        },
        splitChunks: {
            chunks: 'all',
            cacheGroups: {
                vendors: {
                    test: /[\\/]node_modules[\\/]/,
                    name: 'vendors',
                    chunks: 'all'
                }
            }
        }
    },
    plugins: [
        // Removed LoadablePlugin - using direct imports
        new webpack.HotModuleReplacementPlugin(),
        new ExtractCssChunksPlugin({
            filename: '[name].css',
            chunkFilename: '[name].css',
            ignoreOrder: true
        }),
        // Development optimizations
        new webpack.DefinePlugin({
            'process.env.NODE_ENV': JSON.stringify('development'),
            'process.env.REACT_APP_ENV': JSON.stringify('development')
        }),
        // Better error reporting
        new webpack.NoEmitOnErrorsPlugin()
    ],
    // Development optimizations
    cache: {
        type: 'filesystem',
        buildDependencies: {
            config: [__filename]
        }
    },
    stats: {
        colors: true,
        modules: false,
        children: false,
        chunks: false,
        chunkModules: false
    }
});
