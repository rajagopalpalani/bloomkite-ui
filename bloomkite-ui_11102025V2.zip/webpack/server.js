const { merge } = require('webpack-merge');
const webpack = require('webpack');
const common = require('./common');
const join = require('path').join;
const path = require('path');
const nodeExternals = require('../scripts/node-externals');
// Removed @loadable/webpack-plugin - using direct imports

module.exports = merge(common, {
    mode: 'development',
    name: 'server',
    target: 'node',
    externals: nodeExternals,
    entry: {
        'app.server': [join(__dirname, '../src/server/index')]
    },
    // devtool: 'inline-source-map',
    devtool: 'hidden-source-map',
    output: {
        filename: '[name].js',
        libraryTarget: 'commonjs2',
        path: join(__dirname, '../public'),
        publicPath: '/'
    },
    module: {
        rules: [
            {
                test: /(\.css|\.scss)$/,
                exclude: /node_modules/,
                use: [
                    "isomorphic-style-loader",
                    {
                        loader: 'css-loader',
                        options: {
                            modules: {
                                localIdentName: '[local]'
                            },
                            url: false
                        }
                    },
                    {
                        loader: 'postcss-loader',
                        options: {
                            postcssOptions: {
                                plugins: [
                                    require('postcss-import')()
                                ]
                            }
                        }
                    },
                    {
                        loader: 'sass-loader',
                        options: {
                            implementation: require('sass'),
                            sassOptions: {
                                includePaths: [path.resolve(__dirname, 'src', 'scss')]
                            },
                            sourceMap: true
                        }
                    }
                ]
            },
            {
                test: /\.css$/,
                include: /node_modules/,
                use: [
                    "isomorphic-style-loader",
                    {
                        loader: 'css-loader',
                        options: {
                            url: false
                        }
                    },
                    {
                        loader: 'postcss-loader',
                        options: {
                            postcssOptions: {
                                plugins: [
                                    require('postcss-import')()
                                ]
                            }
                        }
                    }
                ]
            }
        ]
    },
    plugins: [
        // Removed LoadablePlugin - using direct imports
        new webpack.optimize.LimitChunkCountPlugin({
            maxChunks: 1
        })
    ]
});
