const webpack = require('webpack');
const { merge } = require('webpack-merge');
const common = require('./common');
const { join } = require('path');
const path = require('path');
const ExtractCssChunksPlugin = require('extract-css-chunks-webpack-plugin');
// Removed @loadable/webpack-plugin - using direct imports

module.exports = merge(common, {
    mode: 'development',
    name: 'client',
    target: 'web',
    entry: {
        'app.client': [
            'webpack-hot-middleware/client',
            join(__dirname, '../src/client/index')
        ]
    },
    devtool: 'inline-source-map',
    output: {
        filename: '[name].js',
        chunkFilename: '[name].chunk.[contenthash].js',
        path: join(__dirname, '../public'),
        publicPath: '/'
    },
    // Removed node configuration - webpack 5 handles this automatically
    module: {
        rules: [
            {
                test: /(\.css|\.scss)$/,
                exclude: /node_modules/,
                use: [
                    "isomorphic-style-loader",
                    ExtractCssChunksPlugin.loader,
                    {
                        loader: 'css-loader',
                        options: {
                            modules: {
                                localIdentName: '[local]'
                            },
                            url: false
                        }
                    },
                    {
                        loader: 'postcss-loader',
                        options: {
                            postcssOptions: {
                                plugins: [
                                    require('postcss-import')()
                                ]
                            }
                        }
                    },
                    {
                        loader: 'sass-loader',
                        options: {
                            implementation: require('sass'),
                            sassOptions: {
                                includePaths: [path.resolve(__dirname, 'src', 'scss')]
                            },
                            sourceMap: true
                        }
                    }
                ]
            },
            {
                test: /\.css$/,
                include: /node_modules/,
                use: [
                    "isomorphic-style-loader",
                    ExtractCssChunksPlugin.loader,
                    {
                        loader: 'css-loader',
                        options: {
                            url: false
                        }
                    },
                    {
                        loader: 'postcss-loader',
                        options: {
                            postcssOptions: {
                                plugins: [
                                    require('postcss-import')()
                                ]
                            }
                        }
                    }
                ]
            }
        ]
    },
    optimization: {
        runtimeChunk: {
            name: 'runtime'
        },
        splitChunks: {
            chunks: 'all',
            cacheGroups: {
                vendors: {
                    test: /[\\/]node_modules[\\/]/,
                    name: 'vendors',
                    chunks: 'all'
                }
            }
        }
    },
    plugins: [
        // Removed LoadablePlugin - using direct imports
        new webpack.HotModuleReplacementPlugin(),
        new ExtractCssChunksPlugin()
    ]
});
