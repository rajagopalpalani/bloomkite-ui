export const resetPasswordSelector = state => ({
    resetPasswordDetails: state.resetPasswordReducer.resetPasswordDetails
    
});