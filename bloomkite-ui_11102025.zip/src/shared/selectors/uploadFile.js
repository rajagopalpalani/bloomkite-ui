export const uploadFileSelector = state => ({
    uploadFileDetails: state.uploadFileReducer.uploadFileDetails,
    
});
