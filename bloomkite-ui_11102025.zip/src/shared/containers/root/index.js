import React from 'react';
import './index.css';

const Root = () => (
    <section className='root'>
    </section>
);

export default Root;
